import copy
import sys

#PROJET Theorie des Graphes GROUPE F1: Dorian SANJIVY, Nathan REVERSAT, Mahmoud ZAAFOURI, Hubert SHUMACHER.

# FONCTIONS

# Ouvrir une table depuis un fichier txt et l'ecrire dans la variable file_content
def lire_fichier(fichier):
    taches = []
    # Ouverture du fichier
    with open(fichier, 'r') as f:
        # Lecture de chaque ligne
        for ligne in f:
            # On split la ligne en fonction des espaces -> on la transforme en chaine de caractère
            # Ensuite on la transforme en liste de int
            row = [int(x) for x in ligne.strip().split()]
            # On ajoute la ligne dans les tâches
            taches.append(row)

    return taches

# Ecrire dans la F1_trace (redirection des prints)
def ecrire_trace(fichier_nom):
    sys.stdout = open("F1_trace/" + fichier_nom + '_trace.txt','wt')

# Ecrire dans la console les logs mis dans la F1_trace
def afficher_trace(fichier_nom):
    with open("F1_trace/" + fichier_nom + '_trace.txt', 'r') as file:
        content = file.read()
        print(content)

# Calcule le nombre de nombres du fichier
def num_value(fichier_memoire):
    value = 0
    for ligne in fichier_memoire:
        for element in ligne:
            value += 1
    return value

# On crée les valeurs fictives et on les initialise
def ajout_fictive(fichier_memoire):

    list_temp = []
    fichier_memoire_fictif = copy.deepcopy(fichier_memoire)

    # on ajoute les arcs de a (tache 0)
    ct = 0
    for ligne in fichier_memoire_fictif:
        # Si la ligne a 2 colonnes
        if (len(ligne) == 2):
            # On ajoute un arc de a vers cette tâche
            fichier_memoire_fictif[ct].append(0)
        ct = ct + 1

    # On rajoute la tâche fictive a
    fichier_memoire_fictif.insert(0, [0,0])

    # On rajoute la tâche fictive w (tache n+1)
    fichier_memoire_fictif.append([len(fichier_memoire_fictif),0])

    # On crée une liste temporaire qui va donner la liste des tâches qui a au moins 1 arc vers l'exterieur
    ct = 0
    for ligne in fichier_memoire_fictif:
        ct = 2
        if (len(ligne) > 2):
            while (ct < len(ligne)):
                list_temp.append(ligne[ct])
                ct = ct + 1


    # On ajoute les arcs de w
    for ligne in fichier_memoire:
        # Si la tâche du fichier temporaire n'est pas dans la liste temporaire (n'a pas au moins 1 arc vers l'exterieur)
        if ligne[0] not in list_temp:
            # On ajoute un arc de cette tâche vers w de coût 0
            fichier_memoire_fictif[len(fichier_memoire_fictif) - 1].append(ligne[0])

    return fichier_memoire_fictif

# Table d'ordonnancement qui va nous permettre d'afficher la matrice et la forme (tache, successeur, coût)
def transformation_ordonnancement(fichier_memoire):
    table_ordonnancement = []
    ct = 0

    # On crée la table d'ordonnancement (tâche, successeur, coût)
    for ligne in fichier_memoire:
        # Pour chaque ligne on vérifie les valeurs s'il existe plus de 2 colonnes.
        if len(ligne) > 2:
            ct = 2
            # Ensuite pour chaque colonne restante on recupère (tâche, successeur, coût)
            while ct < len(ligne):
                # Ajout (tâche, successeur, coût) dans la table d'ordonnancement
                table_ordonnancement.append([ligne[ct],ligne[0],fichier_memoire[ligne[ct]][1]])
                ct = ct + 1

    # Donne le chiffre dont on va avoir besoin pour le tri (premier chiffre de la ligne)
    def tri_par_premier_chiffre(ligne):
        return ligne[0]

    # On remet la table dans l'ordre pour ne pas avoir de problèmes d'affichage par la suite
    # On le fait en fonction du premier chiffre de la ligne
    table_ordonnancement = sorted(table_ordonnancement, key=tri_par_premier_chiffre)

    return table_ordonnancement

# On print le tableau d'ordonnancement
def print_ordonnancement(num_sommets, num_arc, table_ordonnancement):
    print("* Création du graphe d'ordonnancement :\n" + str(num_sommets) + " sommets\n" + str(num_arc) + " arcs")

    for ligne in table_ordonnancement:
        print(str(ligne[0]) + " -> " + str(ligne[1]) + " = " + str(ligne[2]))

    print("\n")
    return 0

# On crée la matrice et on l'initialise
def matrice_creation(num_sommets):

    # Créer une matrice vide de taille n x n
    matrice = [[" " for x in range(num_sommets + 1)] for y in range(num_sommets + 1)]

    # Remplir la matrice avec des "*" et afficher les valeurs de bordure
    for i in range(len(matrice)):
        for j in range(len(matrice)):
            matrice[i][j] = "*"

    for i in range(len(matrice)):
        if (i == 0):
            matrice[i][0] = " "
        else:
            matrice[i][0] = i-1

    for j in range(len(matrice)):
        if (j == 0):
            matrice[0][j] = " "
        else:
            matrice[0][j] = j-1
    return matrice

# On remplie la matrice déjà crée au préablable avec les valeurs de la table d'ordonnancement
def matrice_remplissage(matrice, table_ordonnancement):
    # Mettre les valeurs dans la matrice

    # Pour toutes les valeurs x d'ordonnancement
    for i in range(len(table_ordonnancement)):

        # Pour toutes les valeurs de la matrice
        for j in range(len(matrice)):

            # Si la valeur de la table d'odonnancement i est egals à la valeur j de la matrice
            if (table_ordonnancement[i][0] == matrice[j][0]):

                # Alors mettre dans la matrice à la position [j] [2ème valeur de la table d'ordonnance +1]
                # La valeur [3ème valeur de la table d'ordonnance] (soit le poids)
                matrice[j][table_ordonnancement[i][1]+1] = table_ordonnancement[i][2]

# On affiche la matrice
def afficher_matrice(matrice):

    # On uniformise la longueur des nombres dans la matrice de sorte à ne pas casser sa forme :
    # si elle contient des nombres à plusieurs chiffres
    for i in range(len(matrice)):
        for j in range(len(matrice[i])):
            matrice[i][j] = str(matrice[i][j]).rjust(2)

    # Afficher la matrice
    # On prend chaque ligne de la matrice puis on convertit chaque élément en string
    # Ensuite on uilise join pour les séparer par un espace
    for row in matrice:
        print("  ".join(str(x) for x in row))

# On regarde si le graph a un circuit + on donne le tableau de rang
def Check_Circuit(fichier_memoire, table_rang):

    # On crée les variables
    list_temp = []
    ct = 0
    ct2 = 0
    nb_point_entre = 1

    # On fait une copie temporaire du fichier memoire que l'on va utiliser ici
    fichier_mem_temp = copy.deepcopy(fichier_memoire)
    nb_sommet = len(fichier_mem_temp)

    print("* Détection de circuit")

    # On cherche la tâche de début (sans antécédent)
    for ligne in fichier_mem_temp:

        # On a trouvé la tâche numero 1
        if (len(ligne) == 2):
            print("* Méthode d’élimination des points d’entrée")

            # On prend cette premiere tâche et on la met dans la liste
            list_temp.append(fichier_mem_temp[0][ct])
            print("Point(s) d’entrée : " + str(list_temp[0]))
            table_rang.append(list_temp)

            # On supprime le premier point d'entrée (ligne)
            print("Suppression des points d’entrée")
            del fichier_mem_temp[ct]

            # On met à jour le tableau
            Update_fichier_mem(fichier_mem_temp, list_temp)

            # Maintenant que la 1ère boucle a été faite on peut faire un WHILE
            while (nb_point_entre > 0) :

                # On finit la boucle si le fichier est vide
                if (fichier_mem_temp == []) :
                    nb_point_entre = 0
                    nb_sommet = 0
                    break

                # On affiche les sommets restants
                print("Sommet(s) restant(s) : ", end="")
                ct2 = 0
                nb_sommet = 0

                for ligne_bis in fichier_mem_temp:
                    print(str(fichier_mem_temp[ct2][0]) + " ", end="")
                    ct2 = ct2 + 1
                    nb_sommet = nb_sommet+1

                # On affiche les nouveaux point d'entrée
                print("\nPoint(s) d’entrée : ", end="")
                ct2 = 0
                list_temp = []
                nb_point_entre = 0

                # On ajoute les nouveaux points d'entrée (2 colonne) dans la liste temporaire
                # Et on augmente la variable qui les comptent
                for ligne_bis in fichier_mem_temp:
                    if (len(ligne_bis) == 2):
                        list_temp.append(fichier_mem_temp[ct2][0])
                        nb_point_entre = nb_point_entre+1
                    ct2 = ct2 + 1

                # On affiche réellement les nouveaux points d'entrée
                ct2 = 0
                for ligne_bis in list_temp:
                    print(str(list_temp[ct2]) + " ", end="")
                    ct2 = ct2 + 1

                # On les ajoute dans le tableau de rang
                table_rang.append(list_temp)

                # Break si la liste est vide/ plus de tâche sans antécedent
                if (list_temp == []):
                    print("\n")
                    break

                # On supprime les points d'entrée
                print("\nSuppression des points d’entrée")
                ct2 = 0

                # On supprime les points d'entrée dans le fichier memoire temporaire
                for ligne_bis in list_temp :
                    while ct2 < len(fichier_mem_temp):
                        if (fichier_mem_temp[ct2][0] == ligne_bis):
                            del fichier_mem_temp[ct2]
                        else:
                            ct2 = ct2 +1
                    ct2 = 0

                # On met à jour le tableau
                Update_fichier_mem(fichier_mem_temp, list_temp)

            # A la fin de la boucle on vérifie le nombre de sommet restant
            if (nb_sommet == 0):
                print("Sommet(s) restant(s) : Aucun")
                print("-> Il n’y a pas de circuit")
                return 0
            # S'il reste plus d'un sommet alors il y a une boucle
            else:
                print("-> pas de tâche sans antécédent donc il y a un circuit")
                return 1

        # Si on arrive à la fin du fichier memoire et qu'aucun point sans antécédent n'est détecté
        elif ((len(ligne) != 2) and ct == len(fichier_mem_temp)-1) :
            print("-> pas de tâche sans antécédent donc il y a un circuit")
            return 1

        ct = ct+1

# On met à jour le tableau lors de la suppression de check circuit, on supprime les arcs des points d'entrée supprimés
def Update_fichier_mem(fichier_mem_temp, list_temp):

    parcour_list = 0
    ct = 0
    ct2 = 0

    # On parcourt la liste temporaire
    while (parcour_list < len(list_temp)):
        # Pour chaque ligne du fichier memoire
        for ligne_bis in fichier_mem_temp:
            # si la ligne de fichier mem a plus de 2 elements
            if (len(ligne_bis) > 2):
                ct2 = 2
                # On parcourt les taches prédecesseurs de la ligne
                while ct2 < len(ligne_bis):
                    # Si on trouve une tâche qui a déjà été supprimée
                    if (list_temp[parcour_list] == fichier_mem_temp[ct][ct2]):
                        # On supprime l'arc
                        del fichier_mem_temp[ct][ct2]
                    ct2 = ct2 + 1
            ct = ct + 1
        parcour_list = parcour_list + 1
        ct = 0

    return fichier_mem_temp

# On check si les valeurs identiques pour tous les arcs incidents vers l’extérieur à un sommet
def Arc_Meme_Valeur(table_ordonnancement):
    #Ici tous les arcs sortant d'une meme tache on forcement la même valeur
    print("Les valeurs pour tous les arcs incidents vers l’extérieur à un sommet sont identiques")
    return 0

# On check s'il y au moins un arc négatif dans la F1_table
def Arc_Valeur_Negative(table_ordonnancement):

    for ligne in table_ordonnancement:
        if (ligne[2] < 0) :
            print("Il y a au moins un arc négatifs")
            return 1

    print("Il n’y a pas d’arcs négatifs")
    return 0

# On check si les arcs de la première tâche sont nuls
def Arc_Entre_Null(table_ordonnancement, table_rang):

    for ligne in table_ordonnancement:
        if (ligne[0] == table_rang[0][0]):
            if (ligne[2] != 0) :
                print("Il y a au moins un arc non nul pour le point d'entrée")
                return 1

    print("Il n'y a pas d'arc non nul pour le point d'entrée")
    return 0

# On fait tous les tests pour voir si la F1_table est une F1_table d'ordonnancement
def Check_Graph_Ordonnancement(fichier_memoire,table_ordonnancement, table_rang, nb_point_entre, nb_point_sortie):
    # test entre
    if nb_point_entre == 1:
        print("il y a un seul point d'entrée, 0")

        # test sortie
        if nb_point_sortie == 1:
            print("il y a un seul point de sortie, " + str(len(fichier_memoire) - 1))
            print("\n")

            # On check s'il y a un circuit
            if (Check_Circuit(fichier_memoire, table_rang) == 0):

                # On check si les valeurs identiques pour tous les arcs incidents vers l’extérieur à un sommet
                if (Arc_Meme_Valeur(table_ordonnancement) == 0):

                    # On check si les arcs de la première tâche sont nuls
                    if (Arc_Entre_Null(table_ordonnancement, table_rang) == 0):

                        # On check s'il y a un arc négatif
                        if (Arc_Valeur_Negative(table_ordonnancement) == 0):
                            return 1
                        else:
                            return 0

                    else:
                        return 0
                else:
                    return 0

            else:
                return 0

        else:
            print("il y a " + str(nb_point_sortie) + " point(s) de sortie")

    else:
        print("il y a " + str(nb_point_entre) + " point(s) d'entrée")
    return 0

# On affiche les rangs
def Afficher_rang(table_rang):
    ct = 0
    ct2 = 0

    print("\nVoici les rangs des sommets: ")
    for ligne in table_rang:
        print("Rang " + str(ct) + ": tâche(s) : ", end="")
        ct = ct + 1

        while ct2 < len(ligne):
            print(str(ligne[ct2]) + " ", end="")
            ct2 = ct2 + 1

        ct2 = 0
        print("\n")

# On calcule les dates au plus tôt
def Calendrier_Au_Plus_Tot(fichier_memoire_fictif, table_rang):
    ordre_traitement = []
    table_prédecesseur = []
    table_date_au_plus_tot = []

    # On initialise l'ordre de traitement (ordre croissant de rang)
    for sous_liste in table_rang:
        for element in sous_liste:
            ordre_traitement.append(element)

    # On initialise la table des prédecesseurs
    for element in ordre_traitement:
        if element != 0:
            table_prédecesseur.append(fichier_memoire_fictif[element][2:])

    # On crée et on calcule la table des dates au plus tôt
    table_date_au_plus_tot.append(0)
    ct = 0
    list_temp = []

    # Pour chaque element de l'ordre de traitement
    for element in ordre_traitement:
        # Si l'element n'est pas le point d'entrée
        if element != 0 :
            # On cherche les prédecesseurs de l'élément
            for element2 in table_prédecesseur[ct-1]:
                # Pour chaque prédecesseur
                for ct2 in range(0,len(ordre_traitement)):
                    # Si le prédecesseur est dans le fichier mémoire fictif
                    if element2 == fichier_memoire_fictif[ct2][0]:
                        # On ajoute dans la liste temoraire
                        # Le poids de l'arc de l'élément + la date au plus tôt du prédecesseur
                        list_temp.append( fichier_memoire_fictif[ct2][1] + table_date_au_plus_tot[ordre_traitement.index(element2)] )
            # On ajoute la valeur max de la liste des dates au plus tôt des prédecesseurs
            table_date_au_plus_tot.append(max(list_temp))
            # On vide la liste temporaire
            list_temp = []
        # On passe à l'élément suivant de la F1_table ordre de traitement
        ct = ct + 1

    # On trie les valeurs par numéro de sommet
    # Zip combine les deux listes en une seule
    # On utilise ordre_traitement comme clé de tri (ordre)
    # On recupère les élément tier de la liste table_date_au_plus_tot
    table_date_au_plus_tot = [x for _, x in sorted(zip(ordre_traitement, table_date_au_plus_tot))]

    # On trie les valeurs par numéro de sommet
    return table_date_au_plus_tot

# On calcule les dates au plus tard
def Calendrier_Au_Plus_Tard(fichier_memoire_fictif, table_rang, table_ordonnancement, date_au_plus_tot):
    ordre_traitement = []
    table_successeur = []
    table_date_au_plus_tard = []

    # On initialise l'ordre de traitement (ordre décroissant de rang)
    for sous_liste in table_rang:
        for element in sous_liste:
            ordre_traitement.insert(0, element)

    # On initialise la table des prédecesseurs
    ct = 0
    ct2 = 0

    # Pour chaque élément de la table ordre de traitement
    for element in ordre_traitement:
        # Ajoute une ligne dans la table successeur
        table_successeur.append([])
        # Pour toutes les valeurs de table d'ordonnancement
        while ct < len(table_ordonnancement):
            # Si elle est égale à l'élément chercher
            if element == table_ordonnancement[ct][0]:
                # Ajouter le successeur dans la table
                table_successeur[ct2].append(table_ordonnancement[ct][1])
            ct = ct+1
        ct = 0
        ct2 = ct2+1

    # On supprime les successeurs de la dernière tâche qui sont inexistants
    table_successeur.pop(0)

    # On crée et on calcule la table des dates au plus tard
    #Ici date_au_plus_tot est la valeur de la dernière date de la liste
    table_date_au_plus_tard.append(date_au_plus_tot)
    ct = 0
    list_temp = []

    # Pour chaque élément de l'ordre de traitement
    for element in ordre_traitement:
        # Si l'élément n'est pas le point d'entrée
        if element != len(ordre_traitement)-1:
            # On cherche les successeurs de l'élément
            for element2 in table_successeur[ct-1]:
                # Pour chaque successeur
                for ct2 in range(0, len(ordre_traitement)):
                    # Si le successeur est dans le fichier memoire fictif
                    if element == fichier_memoire_fictif[ct2][0]:
                        # On ajoute à la liste temporaire
                        # La date au plus tard du successeur - la valeur de l'arc de l'element
                        list_temp.append(table_date_au_plus_tard[ordre_traitement.index(element2)]
                                         - fichier_memoire_fictif[ct2][1])
            # On ajoute la valeur max de la liste des dates au plus tard des successeurs
            table_date_au_plus_tard.append(min(list_temp))
            # On vide la liste temporaire
            list_temp = []
        # On passe à l'élément suivant de la table ordre de traitement
        ct = ct + 1

    # On trie les valeurs par numero de sommet (meme fonctionnement que date au plus tot)
    table_date_au_plus_tard = [x for _, x in sorted(zip(ordre_traitement, table_date_au_plus_tard))]

    return table_date_au_plus_tard

# Calcule les marges
def calcule_marge_total(date_au_plus_tard, date_au_plus_tot):
    marges_total = []
    for ct in range(0, len(date_au_plus_tard)):
        marges_total.append(date_au_plus_tard[ct] - date_au_plus_tot[ct])

    return marges_total

# Cette fonction permet d'afficher les dates de début et de fin des tâches d'un projet avec une belle présentation
def afficher_dates_projet(date_au_plus_tot, date_au_plus_tard, marges_total):
    print("Dates du Projet:")
    print("| Tâches | tôt | tard | marges |")
    print("--------------------------------")

    # Parcourir les tâches pour afficher les dates et les marges de chaque tâche
    for tache in range(len(date_au_plus_tot)):
        # Affiche les informations de la tâche dans le tableau
        # Utilise la méthode format pour insérer les variables dans la chaîne de caractères
        # Les valeurs entre accolades sont des espaces réservés pour les variables
        # Les chiffres suivis de deux points et d'un signe inférieur (<)
        # permettent de définir la largeur minimale de l'espace réservé
        print("|  {0: <4} |  {1: <3} |  {2: <4} |  {3: <5} |".format(tache, date_au_plus_tot[tache], date_au_plus_tard[tache], marges_total[tache]))

    # Affiche une ligne de séparation pour indiquer la fin du tableau
    print("--------------------------------")

# Calcule des chemins critiques
def trouver_chemin_critique(fichier_memoire_fictif, marges_total, table_rang):
    # Fonction récursive pour effectuer un parcours en profondeur
    def dfs(sommet, chemin):
        # Si nous avons atteint le sommet 0, ajoutez le chemin actuel aux chemins critiques (inversé)
        if sommet == 0:
            chemins_critiques.append(chemin[::-1])
        else:
            # Parcourez tous les prédécesseurs du sommet actuel
            for predecesseur in fichier_memoire_fictif[sommet][2:]:
                # Si la marge totale du prédécesseur est égale à 0, continuez le chemin en profondeur avec ce prédécesseur
                if marges_total[predecesseur] == 0:
                    dfs(predecesseur, chemin + [predecesseur])

    # Initialise la liste des chemins critiques
    chemins_critiques = []

    # Obtenez le dernier sommet (le plus grand rang) à partir de la table des rangs
    dernier_sommet = table_rang[-1][0]

    # Commencez à partir du dernier sommet
    dfs(dernier_sommet, [dernier_sommet])

    # Retournez la liste des chemins critiques trouvés
    return chemins_critiques

# Affiche chemins critiques
def afficher_chemin_critique(chemins_critiques):
    # Affiche un message d'introduction pour les chemins critiques
    print("Chemin(s) critique(s) : ")

    # Parcourez tous les chemins critiques trouvés
    for chemin in chemins_critiques:
        # Pour chaque sommet du chemin, sauf le dernier, affichez le sommet et une flèche
        for ct in range(len(chemin) - 1):
            print(str(chemin[ct]) + " -> ", end="")
        # Affichez le dernier sommet du chemin critique
        print(chemin[-1])


#La fonction main (permet au programme de boucler)
def main():
    end_program = False
    while not end_program:
        try:
            # On initialise les tableaus et valeurs
            fichier_nom = input("Quel fichier voulez vous ouvrir ?\n")

            fichier_memoire = lire_fichier("F1_table/" + fichier_nom + ".txt")

            ecrire_trace(fichier_nom)

            # On crée les valeurs fictives et on les initialise
            fichier_memoire_fictif = ajout_fictive(fichier_memoire)

            num_sommets = len(fichier_memoire_fictif)

            num_arc = num_value(fichier_memoire_fictif) - num_sommets * 2

            # On crée la table_ordonnancement
            table_ordonnancement = transformation_ordonnancement(fichier_memoire_fictif)

            # On affiche la table_ordonnancement
            print_ordonnancement(num_sommets, num_arc, table_ordonnancement)

            # On initialise la matrice et on la remplit puis on l'affiche
            matrice = matrice_creation(num_sommets)

            matrice_remplissage(matrice, table_ordonnancement)

            print("Matrice des valeurs :")
            afficher_matrice(matrice)

            # DEBUT DES TESTS GRAPH D'ORDONNANCEMENT
            print("\n")

            # Déjà calculer lors de la mise en place des taches fictives
            nb_point_entre = 1
            nb_point_sortie = 1
            table_rang = []

            # On fait tous les tests pour voir si la able est une table d'ordonnancement
            Ordonnancement = Check_Graph_Ordonnancement(fichier_memoire_fictif, table_ordonnancement, table_rang, nb_point_entre, nb_point_sortie)

            if Ordonnancement == 1:
                print("-> C’est un graphe d’ordonnancement")
            else:
                print("-> Ce n'est pas un graphe d’ordonnancement")

            # On affiche les rangs si c'est un graphe d'ordonnancement
            if Ordonnancement == 1:
                Afficher_rang(table_rang)

                # Calcule le calendrier au plus tôt
                date_au_plus_tot = Calendrier_Au_Plus_Tot(fichier_memoire_fictif, table_rang)

                # Calcule le calendrier au plus tard
                date_au_plus_tard = Calendrier_Au_Plus_Tard(fichier_memoire_fictif, table_rang, table_ordonnancement, date_au_plus_tot[-1])

                # Calcule les marges
                marges_total = calcule_marge_total(date_au_plus_tard, date_au_plus_tot)

                # Affiche les dates du projet
                afficher_dates_projet(date_au_plus_tot, date_au_plus_tard, marges_total)

                # Calcule le chemins critiques et l'affiche
                chemins_critiques = trouver_chemin_critique(fichier_memoire_fictif, marges_total, table_rang)
                afficher_chemin_critique(chemins_critiques)

            # Afficher les output sur la console python
            sys.stdout = sys.__stdout__
            afficher_trace(fichier_nom)

        # Si le fichier n'est pas trouver afficher : "Fichier introuvable!" et relancer la boucle
        # Permet de ne pas planter
        except FileNotFoundError:
            print("Fichier introuvable!")



#MAIN
main()
